////////////////////////////////////////////////////////////////////////////////////
// Header_File_Name : CBrClassDef.h
// Description      : This Header File Contains All the Class "PROTOTYPES" and some 
//					  "TEMPLATES" Needed for CBr.
// Coded By         : Muhammad Shahbaz
// Project          : Coded Brain
////////////////////////////////////////////////////////////////////////////////////
#ifndef __CBrClassDef_h__
#define __CBrClassDef_h__
#include "CBrClassPT.h"
////////////////////////////////////////////////////////////////////////////////////
//CBR PRINT CLASS
////////////////////////////////////////////////////////////////////////////////////
void CBRPrint::Show(string STR, char type){
	if (type == 'i'){
		cout << "\r" << flush;
		STR = "[INFO] : " + STR + ".";
		for (int i = 0; i < STR.length(); i++){
			cout << STR[i];
			Sleep(5);
		}
		cout << endl;
	}
	else if (type == 'l'){
		cout << "\r" << flush;
		STR = "[LISTENED] : " + STR + ".";
		for (int i = 0; i < STR.length(); i++){
			cout << STR[i];
			Sleep(5);
		}
		cout << endl;
	}
	else if (type == 'r'){
		cout << "\r" << flush;
		STR = "[RESPONSE] : " + STR + ".";
		for (int i = 0; i < STR.length(); i++){
			cout << STR[i];
			Sleep(5);
		}
		cout << endl;
	}
	else if (type == 's'){
		cout << "\r" << flush;
		STR = "[SENSE] : " + STR + ".";
		for (int i = 0; i < STR.length(); i++){
			cout << STR[i];
			Sleep(5);
		}
		cout << endl;
	}
	else if (type == 'm'){
		cout << "\r" << flush;
		STR = "[MATHS] : " + STR + ".";
		for (int i = 0; i < STR.length(); i++){
			cout << STR[i];
			Sleep(5);
		}
		cout << endl;
	}
	else if (type == 'd'){
		cout << "\r" << flush;
		STR = "[CBR DIRECTORY] : " + STR + ".";
		cout << STR;
		cout << endl;
	}
}
void CBRPrint::CLS(){
	system("cls");
}
void CBRPrint::Line(){
	cout << "--------------------------------------------------------------------------------";
}
////////////////////////////////////////////////////////////////////////////////////
//SPEAKER CLASS
////////////////////////////////////////////////////////////////////////////////////
SpeakerClass::SpeakerClass(){
	hr = S_OK;
	mVoice.Release();
}
bool SpeakerClass::Start(){
	hr = COMInit::Initialize();
	if (FAILED(hr)){
		cout << "[ERROR]: Initialize Failed." << endl;
		return 0;
	}
	hr = mVoice.CoCreateInstance(CLSID_SpVoice);
	if (FAILED(hr)){
		cout << "[ERROR]: CoCreateInstance Failed." << endl;
		return 0;
	}
	//cout << "[SUCCESS]: Speaker Started." << endl;
	return 1;
}
void SpeakerClass::Stop(){
	if (hr == S_FALSE){
		hr = S_OK;
	}
	if (mVoice){
		mVoice.Release();
	}
	if (CWofStrToSpeak != NULL){
		CWofStrToSpeak = NULL;
	}
	//cout << "[SUCCESS]: Speaker Stopped." << endl;
}
void SpeakerClass::Speak(string StrToSpeak){
	USES_CONVERSION;
	CWofStrToSpeak = A2CW(StrToSpeak.c_str());
	mVoice->Speak(CWofStrToSpeak, SPF_DEFAULT, NULL);
	CWofStrToSpeak = NULL;
}
////////////////////////////////////////////////////////////////////////////////////
//LISTENER CLASS
////////////////////////////////////////////////////////////////////////////////////
ListenerClass::ListenerClass(){
	hr = S_OK;
	mRec.Release();
	mAudio.Release();
	mCon.Release();
	mGrm.Release();
	mEvent.Clear();
	mOut = NULL;
}
bool ListenerClass::Start(){
	hr = COMInit::Initialize();
	if (FAILED(hr)){
		cout << "[ERROR]: Initialize Failed." << endl;
		return 0;
	}
	hr = mRec.CoCreateInstance(CLSID_SpInprocRecognizer);
	if (FAILED(hr)){
		cout << "[ERROR]: CoCreateInstance Failed." << endl;
		return 0;
	}
	hr = mRec->CreateRecoContext(&mCon);
	if (FAILED(hr)){
		cout << "[ERROR]: CreateRecoContext Failed." << endl;
		return 0;
	}
	hr = mCon->SetNotifyWin32Event();
	if (FAILED(hr)){
		cout << "[ERROR]: SetNotifyWin32Event Failed." << endl;
		return 0;
	}
	hr = mCon->SetInterest(SPFEI(SPEI_RECOGNITION), SPFEI(SPEI_RECOGNITION));
	if (FAILED(hr)){
		cout << "[ERROR]: SetInterest Failed." << endl;
		return 0;
	}
	hr = SpCreateDefaultObjectFromCategoryId(SPCAT_AUDIOIN, &mAudio);;
	if (FAILED(hr)){
		cout << "[ERROR]: SpCreateDefaultObjectFromCategoryId Failed." << endl;
		return 0;
	}
	hr = mRec->SetInput(mAudio, TRUE);
	if (FAILED(hr)){
		cout << "[ERROR]: SetInput Failed." << endl;
		return 0;
	}
	hr = mCon->CreateGrammar(0, &mGrm);
	if (FAILED(hr)){
		cout << "[ERROR]: CreateGrammar Failed." << endl;
		return 0;
	}
	cout << "[SUCCESS]: Listener Started." << endl;
	return 1;
}
bool ListenerClass::ActivateRecognizer(){
	hr = mRec->SetRecoState(SPRST_ACTIVE);
	if (FAILED(hr)){
		cout << "[ERROR]: SetRecoState Failed." << endl;
		return 0;
	}
}
bool ListenerClass::DeActivateRecognizer(){
	hr = mRec->SetRecoState(SPRST_INACTIVE);
	if (FAILED(hr)){
		cout << "[ERROR]: SetRecoState Failed." << endl;
		return 0;
	}
}
bool ListenerClass::LoadDictation(){
	hr = mGrm->LoadDictation(NULL, SPLO_STATIC);
	if (FAILED(hr)){
		cout << "[ERROR]: LoadDictation Failed." << endl;
		return 0;
	}
	return 1;
}
bool ListenerClass::UnLoadDictation(){
	hr = mGrm->UnloadDictation();
	if (FAILED(hr)){
		cout << "[ERROR]: UnLoadDictation Failed." << endl;
		return 0;
	}
	return 1;
}
bool ListenerClass::ActivateDictation(){
	hr = mGrm->SetDictationState(SPRS_ACTIVE);
	if (FAILED(hr)){
		cout << "[ERROR]: SetDictationState Failed." << endl;
		return 0;
	}
	return 1;
}
bool ListenerClass::DeActivateDictation(){
	hr = mGrm->SetDictationState(SPRS_INACTIVE);
	if (FAILED(hr)){
		cout << "[ERROR]: SetDictationState Failed." << endl;
		return 0;
	}
	return 1;
}
bool ListenerClass::LoadCmdFromSource(){
	hr = mGrm->LoadCmdFromResource(NULL, MAKEINTRESOURCEW(ResCBrGrammar), L"SRGRAMMAR", MAKELANGID(LANG_NEUTRAL, SUBLANG_NEUTRAL), SPLO_DYNAMIC);
	if (FAILED(hr)){
		cout << "[ERROR]: LoadCmdFromResource Failed." << endl;
		return 0;
	}
	return 1;
}
bool ListenerClass::ActivateAllRule(){
	hr = mGrm->SetRuleState(NULL, NULL, SPRS_ACTIVE);
	if (FAILED(hr)){
		cout << "[ERROR]: All Rule Activation Failed." << endl;
		return 0;
	}
	else
	{
		return 1;
	}
}
bool ListenerClass::DeActivateAllRule(){
	hr = mGrm->SetRuleState(NULL, NULL, SPRS_INACTIVE);
	if (FAILED(hr)){
		cout << "[ERROR]: All Rule DeActivation Failed." << endl;
		return 0;
	}
	else
	{
		return 1;
	}
}
bool ListenerClass::ActivateRule(ULONG RuleID){
	hr = mGrm->SetRuleIdState(RuleID, SPRS_ACTIVE);
	if (FAILED(hr)){
		cout << "[ERROR]: Rule ID " << RuleID << " Activation Failed." << endl;
		return 0;
	}
	else
	{
		return 1;
	}
}
bool ListenerClass::DeActivateRule(ULONG RuleID){
	hr = mGrm->SetRuleIdState(RuleID, SPRS_INACTIVE);
	if (FAILED(hr)){
		cout << "[ERROR]: Rule ID " << RuleID << " DeActivation Failed." << endl;
		return 0;
	}
	else
	{
		return 1;
	}
}
bool ListenerClass::AddNewStringToGrammar(string RuleName, int RuleID,string StringToAdd){
	USES_CONVERSION;
	hr=mGrm->GetRule(A2CW(RuleName.c_str()), RuleID, SPRAF_TopLevel | SPRAF_Active, 1, &SPAddState);
	if (FAILED(hr)){
		cout << "[ERROR]: GetRule Failed." << endl;
		return 0;
	}
	hr=mGrm->AddWordTransition(SPAddState, NULL,A2CW(StringToAdd.c_str()), L"", SPWT_LEXICAL, 1, NULL);
	if (FAILED(hr)){
		cout << "[ERROR]: AddWordTransition Failed." << endl;
		return 0;
	}
	hr=mGrm->Commit(0);
	if (FAILED(hr)){
		cout << "[ERROR]: Commit Failed." << endl;
		return 0;
	}
	else{
		return 1;
	}
}
bool ListenerClass::RemoveNewlyAddedStrings(){
	hr = mGrm->ClearRule(SPAddState);
	if (FAILED(hr)){
		cout << "[ERROR]: ClearRule Failed." << endl;
		return 0;
	}
	else{
		return 1;
	}
}
void ListenerClass::Stop(){
	if (mGrm){
		mGrm.Release();
	}
	if (mCon){
		mCon->SetNotifySink(NULL);
		mCon.Release();
	}
	if (mRec){
		mRec.Release();
	}
	mEvent.Clear();
	mIPhrase = NULL;
	::CoTaskMemFree(mOut);
	//cout << "[SUCCESS]: Listener Stopped." << endl;
}
string ListenerClass::Listen(){
	hr = mCon->WaitForNotifyEvent(INFINITE);
	if (FAILED(hr)){
		cout << "[ERROR]: WaitForNotifyEvent Failed." << endl;
		return "";
	}
	if (mEvent.GetFrom(mCon) != S_OK){
		cout << "[ERROR]: WaitForNotifyEvent Failed." << endl;
		return "";
	}
	else{
		if (mEvent.eEventId == SPEI_RECOGNITION){
			mIPhrase = mEvent.RecoResult();
			hr = mIPhrase->GetText(SP_GETWHOLEPHRASE, SP_GETWHOLEPHRASE, TRUE, &mOut, NULL);
			if (FAILED(hr)){
				cout << "[ERROR]: GetText Failed." << endl;
				return "";
			}
			return CW2A(mOut);
		}
	}
}
////////////////////////////////////////////////////////////////////////////////////
//Function for Opening Files
////////////////////////////////////////////////////////////////////////////////////
void OpenFile(string FileName){
	USES_CONVERSION;
	ShellExecute(NULL, L"open", A2CW(FileName.c_str()), NULL, NULL, SW_SHOWDEFAULT);
}
////////////////////////////////////////////////////////////////////////////////////
//INFO FETCHER CLASS
////////////////////////////////////////////////////////////////////////////////////
InfoFetcher::InfoFetcher(){
	pos = -1;
}
int InfoFetcher::LengthOfFile(string FileName){
	string temp;
	int len = 0;
	fstream file(FileName.c_str(), ios::in);
	if (!file.is_open()){
		throw FileOpeningError();
	}
	else{
		while (getline(file, temp)){
			len++;
		}
	}
	file.flush();
	file.clear();
	file.close();
	return len;
}
////////////////////////////////////////////////////////////////////////////////////
//PARSER CLASS
////////////////////////////////////////////////////////////////////////////////////
Parser::Parser(int TotalRemovableStrings) :RSTRObj(TotalRemovableStrings){
	pos = -1;
}
//Capitalizer
string Parser::toCap(string Target){
	for (int i = 0; i < Target.length(); i++){
		if (Target[i] >= 'a'&&Target[i] <= 'z'){
			Target[i] -= 32;
		}
	}
	return Target;
}
//It replaces Strstr's StrTarget with Source even Inside Words
void Parser::StringReplace(string &Strstr, string StrTarget, string StrSource){
	pos = -1;
	pos = Strstr.find(StrTarget);
	if ((int)pos != -1){
		Strstr.erase(pos, StrTarget.length());
		Strstr.insert(pos, StrSource);
	}
}
//It Removes All Spaces
void Parser::StringAllSpaceRemove(string &Strstr){
	for (int i = 0; i < Strstr.length(); i++){
		if (Strstr[i] == ' '){
			Strstr.erase(i, 1);
		}
	}
}
//It Removes more than One Space
void Parser::StringExtraSpaceRemove(string &Strstr){
	for (int i = 0; i<Strstr.length(); i++){
		while (Strstr[i] == ' '&&Strstr[i + 1] == ' '){
			Strstr.erase(i, 1);
		}
		if (i == 0 || (i == Strstr.length() - 1)){
			while (Strstr[i] == ' '){
				Strstr.erase(i, 1);
			}
		}
	}
}
//It returns the Position of Str in Source
size_t Parser::FindStr(string Source, string Str){
	Source.insert(0, 1, ' ');
	Source.insert(Source.length(), 1, ' ');
	Str.insert(0, 1, ' ');
	Str.insert(Str.length(), 1, ' ');
	pos = Source.find(Str);
	if (pos >= 0 && pos <= Source.length() - 1){
		return pos;
	}
	else{
		return -1;
	}
}
//It replaces Strstr's StrTarget with Source Word
void Parser::StringReplaceWord(string &Strstr, string StrTarget, string StrSource){
	pos = -1;
	pos = (int)FindStr(Strstr, StrTarget);
	if ((int)pos != -1){
		Strstr.erase(pos, StrTarget.length());
		Strstr.insert(pos, StrSource);
	}
}
//It Cleans A String for Use in Memory or MathSolver etc Objects
string Parser::CleanSTR(string Target, string ForWhat){
	if (ForWhat == "MATHS"){
		for (int i = 0; i < Target.length(); i++){
			if (isdigit(Target[i])){
				continue;
			}
			else if (Target[i] == '/' || Target[i] == '*' || Target[i] == '+' || Target[i] == '-'){
				continue;
			}
			else{
				Target.erase(i, 1);
				i--;
			}
		}
		return Target;
	}
	else if (ForWhat == "SIMPLEQUESTION"){
		StringExtraSpaceRemove(Target);
		for (int i = 0; i < RSTRObj.GetSize(); i++){
			StringReplaceWord(Target, RSTRObj.GetStr(i), "");
		}
		StringExtraSpaceRemove(Target);
		return Target;
	}
	return Target;
}
//It counts Words in String
int Parser::CountWords(string Target){
	int counter = 0;
	for (int i = 0; i < Target.length(); i++){
		if (Target[i] == ' '){
			counter++;
		}
	}
	counter++;
	return counter;
}
//It transposes Strings
string Parser::Transpose(string Target){
	int j = 0, TotalWords = CountWords(Target);
	string buffer = "", hold = "", Output = "";
	const string _1[16] = { "MYSELF", "DREAMS", "WEREN'T", "AREN'T", "I'VE", "MINE", "MY", "WERE", "MOM", "I AM", "I'M", "DAD", "MY", "AM", "I'D", "I" };
	const string _2[16] = { "YOURSELF", "DREAM", "WASN'T", "AM NOT", "YOU'VE", "YOURS", "YOUR", "WAS", "MOTHER", "YOU ARE", "YOU'RE", "FATHER", "YOUR", "ARE", "YOU'D", "YOU" };
	for (int i = 0; i <= TotalWords; i++){
		buffer = hold = "";
		for (int i = j; i < Target.length(); i++){
			if (Target[i] != ' '){
				buffer.push_back(Target[i]);
			}
			else{
				break;
			}
		}
		hold = buffer;
		for (int i = 0; i < 16; i++){
			if (buffer == _1[i]){
				buffer = _2[i];
				break;
			}
			else if (buffer == _2[i]){
				buffer = _1[i];
				break;
			}
			else{
				continue;
			}
		}
		j += buffer.length() + 1;
		StringReplaceWord(Target, hold, buffer);
		Output += buffer + " ";
	}
	StringExtraSpaceRemove(Output);
	return Output;
}
////////////////////////////////////////////////////////////////////////////////////
//GREETING CLASS
////////////////////////////////////////////////////////////////////////////////////
Greetings::Greetings(int TotalGreetings) :LoadArray(TotalGreetings), SizeGRT(TotalGreetings){
	CountGRT = -1;
	GRT = new string[TotalGreetings];
	LoadArray::Load("WelcomeGreatings.txt");
	for (int i = 0; i < SizeGRT; i++){
		GRT[i] = LoadArray::Get(i);
	}
}
Greetings::~Greetings(){
	delete[]GRT;
}
string Greetings::GetGRT(int Index)const{
	return GRT[Index];
}
int Greetings::GetSizeGRT()const{
	return SizeGRT;
}
////////////////////////////////////////////////////////////////////////////////////
//QUESTION STRINGS CLASS
////////////////////////////////////////////////////////////////////////////////////
QuestionStrings::QuestionStrings(int TotalQuestionStrings) :TotalLines(TotalQuestionStrings), SizeQStr(163), SizeSQStr(12), LoadArray(TotalQuestionStrings) {
	CountQStr = CountSQStr = -1;
	QStr = new string[SizeQStr];
	SQStr = new string[SizeSQStr];
	LoadArray::Load("Words_That_Determine_Questions.txt");
	string temp;
	for (int i = 0; i < TotalLines; i++){
		temp = LoadArray::Get(i);
		switch (temp[0])
		{
		case '#':
			CountSQStr++;
			temp.erase(0, 1);
			SQStr[CountSQStr] = temp;
			break;
		default:
			CountQStr++;
			QStr[CountQStr] = temp;
			break;
		}
	}
}
QuestionStrings::~QuestionStrings(){
	delete[]QStr;
	delete[]SQStr;
}
string QuestionStrings::GetQStr(int Index)const{
	return QStr[Index];
}
string QuestionStrings::GetSQStr(int Index)const{
	return SQStr[Index];
}
int QuestionStrings::GetTotalLines()const{
	return TotalLines;
}
int QuestionStrings::GetSizeQStr()const{
	return SizeQStr;
}
int QuestionStrings::GetSizeSQStr()const{
	return SizeSQStr;
}
////////////////////////////////////////////////////////////////////////////////////
//REMOVABLE STRINGS CLASS
////////////////////////////////////////////////////////////////////////////////////
RemovableStrings::RemovableStrings(int TotalRemovableStrings) :LoadArray(TotalRemovableStrings), SizeStr(TotalRemovableStrings){
	CountRemovableStrings = -1;
	Str = new string[TotalRemovableStrings];
	LoadArray::Load("Remove_these_to_getpoint.txt");
	for (int i = 0; i < TotalRemovableStrings; i++){
		Str[i] = LoadArray::Get(i);
	}
}
RemovableStrings::~RemovableStrings(){
	delete[]Str;
}
string RemovableStrings::GetStr(int Index)const{
	return Str[Index];
}
int RemovableStrings::GetSize()const{
	return SizeStr;
}
////////////////////////////////////////////////////////////////////////////////////
//MATH SOLVER CLASS
////////////////////////////////////////////////////////////////////////////////////
int MathSolver::IntFindFirstMathSign(string Strstr, int IntPos, int Flag){
	int IntPosMathSign = -1;
	if (Flag == 0){
		for (int i = IntPos; i < Strstr.length(); i++){
			for (int j = 0; j < StrMathSign.length(); j++){
				if (Strstr[i] == StrMathSign[j]){
					IntPosMathSign = i;
					return IntPosMathSign;
				}
			}
		}
	}
	else if (Flag == 1){
		for (int i = 0; i < IntPos; i++){
			for (int j = 0; j < StrMathSign.length(); j++){
				if (Strstr[i] == StrMathSign[j]){
					IntPosMathSign = i;
					return IntPosMathSign;
				}
			}
		}
		return IntPosMathSign;
	}
	else{
		throw "[Error]: Arguments Error|Flag Can Only Be 0 or 1.";
	}
	return IntPosMathSign;
}
//It Returns Specific Mathametical Sign Position in a String
int MathSolver::IntFindFirstMathSign(string Strstr, char ChrMathSign){
	int IntPosMathSing = -1;
	for (int i = 0; i < Strstr.length(); i++){
		if (Strstr[i] == ChrMathSign){
			//Returning Position of Sign
			IntPosMathSing = i;
			return IntPosMathSing;
		}
	}
	return IntPosMathSing;
}
//It Returns Specific Mathametical Sign Position in a String
int MathSolver::IntFindLastMathSign(string Strstr, char ChrMathSign){
	int IntPosMathSing = -1;
	for (int i = 0; i < Strstr.length(); i++){
		if (Strstr[i] == ChrMathSign){
			//Returning Position of Sign
			IntPosMathSing = i;
		}
	}
	return IntPosMathSing;
}
//It Retruns Last Mathematical Sign Position From(0) or Upto(1) Specific Index in a String
int MathSolver::IntFindLastMathSign(string Strstr, int IntPos, int Flag){
	int IntPosMathSign = -1;
	if (Flag == 0){
		for (int i = IntPos; i < Strstr.length(); i++){
			for (int j = 0; j < StrMathSign.length(); j++){
				if (Strstr[i] == StrMathSign[j]){
					IntPosMathSign = i;
				}
			}
		}
		return IntPosMathSign;
	}
	else if (Flag == 1){
		for (int i = 0; i < IntPos; i++){
			for (int j = 0; j < StrMathSign.length(); j++){
				if (Strstr[i] == StrMathSign[j]){
					IntPosMathSign = i;
				}
			}
		}
		return IntPosMathSign;
	}
	else{
		throw "Flag Can Only Be 0 or 1";
	}
}
//This Function Extract Chunk of Operation From String Using MathSign
string MathSolver::StrChunkExtract(string Strstr, char ChrMathSign){
	int IntPosMathSign = -1;
	IntPosMathSign = IntFindFirstMathSign(Strstr, ChrMathSign);
	IntPosPre = -1;
	IntPosPre = IntFindLastMathSign(Strstr, IntPosMathSign, 1);
	IntPosPost = -1;
	IntPosPost = IntFindFirstMathSign(Strstr, IntPosMathSign + 1, 0);
	Chunk.clear();
	if (IntPosMathSign != -1 && IntPosPre != -1 && IntPosPost != -1){
		for (int i = IntPosPre + 1; i < IntPosMathSign; i++){
			Chunk.push_back(Strstr[i]);
		}
		Chunk.push_back(ChrMathSign);
		for (int i = IntPosMathSign + 1; i < IntPosPost; i++){
			Chunk.push_back(Strstr[i]);
		}
		return Chunk;
	}
	else if (IntPosMathSign != -1 && IntPosPre != -1 && IntPosPost == -1){
		for (int i = IntPosPre + 1; i < Strstr.length(); i++){
			Chunk.push_back(Strstr[i]);
		}
		return Chunk;
	}
	else if (IntPosMathSign != -1 && IntPosPre == -1 && IntPosPost != -1){
		for (int i = 0; i < IntPosPost; i++){
			Chunk.push_back(Strstr[i]);
		}
		return Chunk;
	}
	else if (IntPosMathSign != -1 && IntPosPre == -1 && IntPosPost == -1){
		return Strstr;
	}
	else{
		throw "[Error]: No Proper Math Operation Chunk Found";
	}
}
//This Function Solve The Chunk Extracted By Chunk Extractor Function
long double MathSolver::LngDblChunkSolve(string StrMathChunk){
	ChrMathSign = NULL;
	for (int i = 0; i < StrMathChunk.length(); i++){
		for (int j = 0; j < StrMathSign.length(); j++){
			if (StrMathChunk[i] == StrMathSign[j]){
				ChrMathSign = StrMathChunk[i];
			}
		}
	}
	int IntPosMathSign = IntFindFirstMathSign(StrMathChunk, 0, 0);
	StrPreNum.clear();
	StrPostNum.clear();
	for (int i = 0; i < IntPosMathSign; i++){
		StrPreNum.push_back(StrMathChunk[i]);
	}
	for (int i = IntPosMathSign + 1; i<StrMathChunk.length(); i++){
		StrPostNum.push_back(StrMathChunk[i]);
	}
	LngDblPreNum = 0;
	LngDblPreNum = stold(StrPreNum);
	LngDblPostNum = 0;
	LngDblPostNum = stold(StrPostNum);
	switch (ChrMathSign)
	{
	case '/':
		if (LngDblPreNum / LngDblPostNum != INFINITY){
			return (LngDblPreNum / LngDblPostNum);
			break;
		}
		else{
			return INFINITY;
			break;
		}
	case '*':
		return (LngDblPreNum*LngDblPostNum);
		break;
	case '+':
		return (LngDblPreNum + LngDblPostNum);
		break;
	case '-':
		return (LngDblPreNum - LngDblPostNum);
		break;
	default:
		throw "[Error]: Wrong Operator";
		break;
	}
}
MathSolver::MathSolver(int TotalRemovableStrings) :StrMathSign("/*+-"), PRSObj(TotalRemovableStrings){
	IntPosPre = -1;
	IntPosPost = -1;
	ChrMathSign = NULL;
	StrPreNum.clear();
	StrPostNum.clear();
	LngDblPreNum = LngDblPostNum = -1;
}
long double MathSolver::MathSolve(string Strstr){
	try{
		while (IntFindFirstMathSign(Strstr, '/') != -1){
			PRSObj.StringReplace(Strstr, StrChunkExtract(Strstr, '/'), to_string(LngDblChunkSolve(StrChunkExtract(Strstr, '/'))));
		}
		while (IntFindFirstMathSign(Strstr, '*') != -1){
			PRSObj.StringReplace(Strstr, StrChunkExtract(Strstr, '*'), to_string(LngDblChunkSolve(StrChunkExtract(Strstr, '*'))));
		}
		while (IntFindFirstMathSign(Strstr, '+') != -1){
			PRSObj.StringReplace(Strstr, StrChunkExtract(Strstr, '+'), to_string(LngDblChunkSolve(StrChunkExtract(Strstr, '+'))));
		}
		while (IntFindFirstMathSign(Strstr, '-') != -1){
			PRSObj.StringReplace(Strstr, StrChunkExtract(Strstr, '-'), to_string(LngDblChunkSolve(StrChunkExtract(Strstr, '-'))));
		}
	}
	catch (exception e){
		if (e.what() == "invalid stold argument"){
			cout << "[Info]: Answer accuracy is not Assured." << endl;
		}
	}
	try{
		return stold(Strstr);
	}
	catch (exception e){
		if (e.what() == "invalid stold argument"){
			cout << "[Info]: Answer accuracy is not Assured." << endl;
		}
	}
}
////////////////////////////////////////////////////////////////////////////////////
//QUESTION ANSWER CLASS
////////////////////////////////////////////////////////////////////////////////////
QuestionAnswer::QuestionAnswer() :SizeQ(2), SizeA(2), PRSObj(187){
	Q = new string[SizeQ];
	A = new string[SizeA];
	CQ = CA = -1;
}
QuestionAnswer::QuestionAnswer(int nOfQues, int nOfAns, int TotalRemovableStrings) : SizeQ(nOfQues), SizeA(nOfAns), PRSObj(TotalRemovableStrings){
	Q = new string[nOfQues];
	A = new string[nOfAns];
	CQ = CA = -1;
}
QuestionAnswer::~QuestionAnswer(){
	delete[]Q;
	delete[]A;
}
void QuestionAnswer::PushQ(string STR){
	++CQ;
	if (CQ >= SizeQ || CQ<0){
		throw OutOfRange();
	}
	else{
		Q[CQ] = STR;
	}
}
void QuestionAnswer::PushA(string STR){
	++CA;
	if (CA >= SizeA || CA<0){
		throw OutOfRange();
	}
	else{
		A[CA] = STR;
	}
}
string QuestionAnswer::GetAns(string Question){
	for (int i = 0; i < SizeQ; i++){
		if ((int)PRSObj.FindStr(Question, Q[i]) >= 0){
			return A[rand() % SizeA];
		}
		else if ((int)PRSObj.FindStr(Q[i], Question) >= 0){
			return A[rand() % SizeA];
		}
		else{
			return "NOANS";
		}
	}
}
////////////////////////////////////////////////////////////////////////////////////
//SIMPLE MATCH CLASS
////////////////////////////////////////////////////////////////////////////////////
SimpleMatch::SimpleMatch(int TotalSimpleMatch) :LoadArray(TotalSimpleMatch){
	Hashes = 0;
	QAIndex = -1;
	Str = new string[TotalSimpleMatch];
	LoadArray::Load("Simple_Match_Database.txt");
	for (int i = 0; i < TotalSimpleMatch; i++){
		Str[i] = LoadArray::Get(i);
		if (Str[i][0] == '#'){
			Hashes++;
		}
	}
	QA = new QuestionAnswer[Hashes];
	string temp = "";
	for (int i = 0; i < TotalSimpleMatch; i++){
		temp = Str[i];
		switch (temp[0])
		{
		case '#':
			QAIndex++;
			break;
		case 'Q':
			temp.erase(0, 1);
			QA[QAIndex].PushQ(temp);
			break;
		case 'A':
			temp.erase(0, 1);
			QA[QAIndex].PushA(temp);
			break;
		default:
			break;
		}
	}
}
string SimpleMatch::Match(string QuestionSTR){
	string Output = "NOANS";
	for (int i = 0; i < Hashes; i++){
		Output = QA[i].GetAns(QuestionSTR);
		if (Output != "NOANS"){
			return Output;
		}
		else{
			continue;
		}
	}
	return Output;
}
////////////////////////////////////////////////////////////////////////////////////
//SIMPLE MATCH CLASS
////////////////////////////////////////////////////////////////////////////////////
Dictionary::Dictionary(int TotalDicLines) :TotalLines(TotalDicLines), LoadArray(TotalDicLines){
	CountWord = CountMeaning = -1;
	LoadArray::Load("Dictionary.txt");
	word = new string[TotalLines / 2];
	meaning = new string[TotalLines / 2];
	string temp;
	for (int i = 0; i < TotalLines; i++){
		temp = LoadArray::Get(i);
		switch (temp[0]){
		case '#':
			CountWord++;
			temp.erase(0, 1);
			word[CountWord] = temp;
			break;
		case '*':
			CountMeaning++;
			temp.erase(0, 1);
			meaning[CountMeaning] = temp;
			break;
		default:
			throw LoadArray::LoadArray_ERROR();
		}
	}
}
string Dictionary::GetMeaning(string Word){
	for (int i = 0; i < TotalLines / 2; i++){
		if (Word == word[i]){
			return meaning[i];
		}
	}
	return "NOANS";
}
////////////////////////////////////////////////////////////////////////////////////
//UNDERSTANDER CLASS
////////////////////////////////////////////////////////////////////////////////////
//Does Good Bye Exist
bool Understander::GoodByeExist(){
	string GB[] = { "TAKE CARE", "BYE", "STOP YOUR SELF", "STOP LISTENING AND GOODBYE", "GOOD BYE" };
	for (int i = 0; i < 5; i++){
		if ((int)PRSObj.FindStr(Input, GB[i])>=0){
			return 1;
		}
	}
	return 0;
}
//Does Maths Exist
bool Understander::MathExist(){
	int pos = -1;
	for (int i = 0; i < Input.length(); i++){
		if (isdigit(Input[i])){
			pos = i;
			break;
		}
	}
	if (pos != -1){
		for (int i = pos; i < Input.length(); i++){
			if (isdigit(Input[i])){
				continue;
			}
			else if (Input[i] == '/' || Input[i] == '*' || Input[i] == '+' || Input[i] == '-' || Input[i] == ' '){
				continue;
			}
			else{
				return 0;
			}
		}
		if (SimpleQuestion() || SpecialSimpleQuestion()){
			string tempI = Input;
			PRSObj.CleanSTR(tempI, "SIMPLEQUESTION");
			for (int i = 0; i < tempI.length(); i++){
				if (tempI[i] >= 'a'&&tempI[i] <= 'z' || tempI[i] >= 'A'&&tempI[i] <= 'Z'){
					return 0;
				}
			}
		}
		return 1;
	}
	else{
		return 0;
	}
}
//Does Hide Terminal Exist
bool Understander::isHideTerminal(){
	if (Input == "HIDE TERMINAL"){
		return 1;
	}
	return 0;
}
//Does Show Terminal Exist
bool Understander::isShowTerminal(){
	if (Input == "SHOW TERMINAL"){
		return 1;
	}
	return 0;
}
//Does Abort Shutdown exist
bool Understander::isAbortShutdown(){
	if (Input == "ABORT SHUTDOWN"){
		return 1;
	}
	return 0;
}
//Does Shutdown exist
bool Understander::isShutdownPC(){
	string SHPC_1[] = { "SHUTDOWN", "TURN OFF", "SWITCH OFF" };
	string SHPC_2[] = { "COMPUTER", "PC", "LAPTOP" };
	for (int i = 0; i < 3; i++){
		if ((int)PRSObj.FindStr(Input, SHPC_1[i]) >= 0){
			for (int j = 0; j < 3; j++){
				if ((int)PRSObj.FindStr(Input, SHPC_2[j]) >= 0){
					return 1;
				}
			}
		}
	}
	return 0;
}
//Does OK exist
bool Understander::isOK(){
	string OK[] = { "OK", "HMM", "I SEE" };
	for (int i = 0; i < 3; i++){
		if ((int)PRSObj.FindStr(Input, OK[i]) >= 0){
			return 1;
		}
	}
	return 0;
}
//Does Goback exist
bool Understander::isGoBack(){
	if (Input == "GO BACK"){
		return 1;
	}
	return 0;
}
//Does SolveMathsExist
bool Understander::isSolveMaths(){
	if (Input == "SOLVE MATHS"){
		return 1;
	}
	return 0;
}
//Does start stop listen exist
bool Understander::isLisStart(){
	if (Input == "CBR LISTEN TO ME" || Input == "CBR START LISTENING" || Input == "LISTEN CBR" || Input == "LISTEN CODED BRAIN"){
		return 1;
	}
	return 0;
}
//Does start stop listen exist
bool Understander::isLisStop(){
	if (Input == "WAIT A BIT" || Input == "WAIT AABIT" || Input == "PAUSE CBR" || Input == "CBR STOP LISTENING"){
		return 1;
	}
	return 0;
}
//Does greetings exist
bool Understander::isGreetings(){
	string grt[] = { "HI CBR", "HELLO CBR", "ASSALAM-O-ALAIKUM CBR" };
	for (int i = 0; i < 3; i++){
		if ((int)PRSObj.FindStr(Input, grt[i]) >= 0){
			return 1;
		}
	}
	return 0;
}
//Does Open File Exist
bool Understander::ISOpenFile(){
	if ((int)PRSObj.FindStr(Input, "OPENFILE") >= 0){
		return 1;
	}
	return 0;
}
//Does Simple Question exist
bool Understander::SimpleQuestion(){
	for (int i = 0; i < QSTRObj.GetSizeQStr(); i++){
		if ((int)PRSObj.FindStr(Input, QSTRObj.GetQStr(i)) >= 0){
			return 1;
		}
	}
	return 0;
}
//Does Special Question exist
bool Understander::SpecialSimpleQuestion(){
	for (int i = 0; i < QSTRObj.GetSizeSQStr(); i++){
		if ((int)PRSObj.FindStr(Input, QSTRObj.GetSQStr(i)) == 0){
			return 1;
		}
	}
	return 0;
}
Understander::Understander(int TotalQuestionStrings, int TotalRemovableStrings) :QSTRObj(TotalQuestionStrings), PRSObj(TotalRemovableStrings){
	Input.clear();
}
//Refresh the Input String
void Understander::Refresh(){
	Input.clear();
	Input = *ARG;
}
//Return Sense in String format
string Understander::GetSense(){
	if (MathExist()){
		return "MATHS";
	}
	else if (isSolveMaths()){
		return "SOLVEMATHS";
	}
	else if (isGoBack()){
		return "GOBACK";
	}
	else if (isOK()){
		return "SAIDOK";
	}
	else if (isLisStart()){
		return "LISTENSTART";
	}
	else if (isLisStop()){
		return "LISTENSTOP";
	}
	else if (isGreetings()){
		return "GREETINGS";
	}
	else if (GoodByeExist()){
		return "GOODBYE";
	}
	else if (ISOpenFile()){
		return "OPENFILE";
	}
	else if (isShutdownPC()){
		return "SHUTDOWNPC";
	}
	else if (isAbortShutdown()){
		return "ABORTSHUTDOWN";
	}
	else if (isShowTerminal()){
		return "SHOWTERMINAL";
	}
	else if (isHideTerminal()){
		return "HIDETERMINAL";
	}
	else if (SpecialSimpleQuestion()){
		return "SPECIALSIMPLEQUESTION";
	}
	else if (SimpleQuestion()){
		return "SIMPLEQUESTION";
	}
	else{
		return "NONSENSE";
	}
}
//Return Input
string Understander::GetInput(){
	return Input;
}
////////////////////////////////////////////////////////////////////////////////////
//CBR FILEWRITER CLASS
////////////////////////////////////////////////////////////////////////////////////
FileWriter::FileWriter(){
	file.flush();
}
FileWriter::~FileWriter(){
	file.close();
	file.flush();
}
void FileWriter::Open(string FileName, ios_base::open_mode OpenMode){
	file.open(FileName.c_str(), OpenMode);
}
void FileWriter::Write(string Line){
	if (file.is_open()){
		file << Line << endl;
	}
}
void FileWriter::Close(){
	file.close();
	file.flush();
}
////////////////////////////////////////////////////////////////////////////////////
//CBR LEARNER CLASS
////////////////////////////////////////////////////////////////////////////////////
Learner::Learner(int TotalRemovableStrings){
	Memorize = new FileWriter;
	ParseforLearn = new Parser(TotalRemovableStrings);
}
Learner::~Learner(){
	delete ParseforLearn;
	Memorize = NULL;
	delete[]Memorize;
}
void Learner::Start(){
	LearnListener.Start();
	LearnListener.LoadDictation();
}
void Learner::Stop(){
	LearnListener.UnLoadDictation();
	LearnListener.Stop();
}
void Learner::Learn(string Question){
	Memorize->Open("Learned.txt", ios::in | ios::ate | ios::out);
	Question = ParseforLearn->toCap(Question);
	Memorize->Write("*" + Question);
	LearnListener.ActivateRecognizer();
	LearnListener.ActivateDictation();
	string temp = LearnListener.Listen();
	LearnListener.DeActivateDictation();
	LearnListener.DeActivateRecognizer();
	temp = ParseforLearn->toCap(temp);
	LearnPrint.Show(temp, 'l');
	LearnPrint.Show("SAVING...", 'i');
	Memorize->Write("#" + temp);
	Memorize->Close();
}
////////////////////////////////////////////////////////////////////////////////////
//CBR LEARNERMATCH CLASS
////////////////////////////////////////////////////////////////////////////////////
LearnedMatch::LearnedMatch(int TotalLines, int TotalRemovableStrings) :LoadArray(TotalLines){
	ParseforLearnedMatch = new Parser(TotalRemovableStrings);
	QAIndex = -1;
	TotalLinesC = TotalLines;
	Q = new string[TotalLines / 2];
	A = new string[TotalLines / 2];
	string temp = "";
	LoadArray::Load("Learned.txt");
	for (int i = 0; i < TotalLines; i++){
		temp = LoadArray::Get(i);
		switch (temp[0])
		{
		case '*':
			QAIndex++;
			temp.erase(0, 1);
			Q[QAIndex] = temp;
			break;
		case '#':
			temp.erase(0, 1);
			A[QAIndex] = temp;
			break;
		default:
			break;
		}
	}
}
LearnedMatch::~LearnedMatch(){
	delete[]Q;
	delete[]A;
	delete ParseforLearnedMatch;
}
string LearnedMatch::GetAnswer(string Question){
	string temp = "", ans = "";
	for (int i = 0; i < TotalLinesC / 2; i++){
		temp = Q[i];
		ans = A[i];
		if ((int)ParseforLearnedMatch->FindStr(Question, temp) >= 0){
			return ans;
		}
		else if ((int)ParseforLearnedMatch->FindStr(temp, Question) >= 0){
			return ans;
		}
	}
	return "NOANS";
}
////////////////////////////////////////////////////////////////////////////////////
//CBR FRAME CLASS
////////////////////////////////////////////////////////////////////////////////////
CBrFrame::CBrFrame() :SensorForHearings(MemPro.LengthOfFile("Words_That_Determine_Questions.txt"), MemPro.LengthOfFile("Remove_these_to_getpoint.txt")), MiningCenter(MemPro.LengthOfFile("Remove_these_to_getpoint.txt")), SelfMemories(MemPro.LengthOfFile("Simple_Match_Database.txt")), DicKnowledge(MemPro.LengthOfFile("Dictionary.txt")), CalculationRegion(MemPro.LengthOfFile("Remove_these_to_getpoint.txt")), NewKnowledge(MemPro.LengthOfFile("Remove_these_to_getpoint.txt")),NewKnowledge_Past(MemPro.LengthOfFile("Learned.txt"),MemPro.LengthOfFile("Remove_these_to_getpoint.txt")),HelloHi(MemPro.LengthOfFile("WelcomeGreatings.txt")){
	Input = Sense = Output = "";
	//Showing the Files being Loaded
	OutScreen.Show("Loading DataBases", 'i');
	OutScreen.CLS();
	OutScreen.Show("Loading DictionaryDB", 'i');
	OutScreen.Show("Loading SimpleMatchDB", 'i');
	OutScreen.Show("Loading RemovableStringsDB", 'i');
	OutScreen.Show("Loading QuestionStringsDB", 'i');
	OutScreen.Show("Loading GreetingsDB", 'i');
	OutScreen.CLS();
	OutScreen.Show("DONE", 'i');
	Sleep(5);
	MathsRes[0] = "ANSWER IS ";
	MathsRes[1] = "It EQUALS TO ";
	MathsRes[2] = "I THINK It IS EXACTLY ";
	MathsRes[3] = "HMM MATHS MY ANSWER IS ";
	MathsRes[4] = "It IS ";
	SPQRes[0] = "MAY BE YES";
	SPQRes[1] = "MAY BE NO";
	SPQRes[2] = "I DON'T WANT TO SAY YES OR NO YET";
	SPQRes[3] = "I WANT TO SAY YES";
	SPQRes[4] = "I WANNA SAY NO";
	NonSenseRes[0] = "I DIDN'T UNDERSTOOD ANYTHING";
	NonSenseRes[1] = "I TRIED TO GET MEANING BUT SORRY I AM UNABLE TO GET THAT. TRY TO SAY MORE CLEARLY IN GRAMMATICALLY TRUE WAY";
	NonSenseRes[2] = "PLEASE REPEAT YOUR QUESTION FOR ME";
	NonSenseRes[3] = "I THINK It IS NOT IN PROPER GRAMMATICS";
	NonSenseRes[4] = "INPUT IS OUT OF SENSE FOR ME";
	LearnRes[0] = "I DONT KNOW THE ANSWER, PLEASE TELL ME ABOUT It I WILL MEMORIZE It";
	LearnRes[1] = "I HAVE NO IDEA ABOUT It PLEASE SAY ANSWER SO I CAN STORE It";
	LearnRes[2] = "AS FOR AS MY PREVIOUS KNOWLEDGE IS CONCERNED I HAVE NO ANSWER TO THIS QUESTION PLEASE TELL ME ABOUT It";
	LearnRes[3] = "TELL ME ABOUT It AND I WILL NEVER FORGET It INSHA ALLAH";
	LearnRes[4] = "PLEASE GIVE ME YOUR COMMENTS";
	GBRes[0] = "OK GOOD BYE";
	GBRes[1] = "It WAS NICE TO TALK TO YOU";
	GBRes[2] = "HAVE A NICE TIME";
	GBRes[3] = "ALLAH HAFIZ";
	GBRes[4] = "TAKE CARE";
}
void CBrFrame::Energize(){
	try{
		//Initializing Listener and Speaker
		OutScreen.CLS();
		OutScreen.Show("Starting Speaker", 'i');
		Speaker.Start();
		//Showing CBRPrint And Speaking Initials
		Sleep(5);
		OutScreen.CLS();
		OutScreen.Show("DONE", 'i');
		system("cls");
		OutScreen.Line();
		system("cls");
		cout << "********************************************************************************";
		cout << "********************************************************************************";
		cout << "                                                                                ";
		cout << "        ************     ***************      *****************\n";
		cout << "        ************     ****************     ******************\n";
		cout << "        *****            ***           ***    ***            ****\n";
		cout << "        ***              ***           ***    ***            ****\n";
		cout << "        ***              **************       ***************\n";
		cout << "        ***              ***           ***    ***            ***\n";
		cout << "        *****            ***           ***    ***             ***\n";
		cout << "        ************     ****************     ***             ***\n";
		cout << "        ************     ***************      ***             ***\n";
		cout << endl;
		cout << "     ---------------------------------------------------------------------\n";
		cout << "                           C O D E D   B R A I N\n";
		cout << "     A N  A R T I F I C I A L  I N T E L L E G E N C E  P R O G R A M M E\n";
		cout << "         C O D E D   B Y   P A S S I O N A T E   P R O G R A M M E R S\n";
		cout << "     ---------------------------------------------------------------------\n\n";
		cout << "********************************************************************************";
		cout << "********************************************************************************";
		Sleep(100);
		Show(1);
		cout << endl;
		Mic.Start();
		Mic.LoadCmdFromSource();
		NewKnowledge.Start();
		Speaker.Speak("All Initializing Procedures...Done.");
		Speaker.Speak("I'm Artificially Intelligent Software; My name is CODED BRAIN; If needed; Call me with my Name");
		OutScreen.Show("Starting Listener", 'i');
	}
	catch (InfoFetcher::FileOpeningError){
		cout << "[Exception] : Some of the Memory Files Failed to Open or Doesn't Exist. Please Verify All Files." << endl;
		exit(1);
	}
	catch (QuestionAnswer::OutOfRange){
		cout << "[Exception] : Array is Full/Empty. No more Objects Can be Pushed/Pulled" << endl;
		exit(1);
	}
	catch (LoadArray<string>::LoadArray_ERROR){
		cout << "[Exception] : Loading Memory Arrays Failed. Try to Reopen; If Failed again Verify Your Copy of Software" << endl;
		exit(1);
	}
	catch (exception e){
		cout << "[Exception] : " << e.what() << endl;
		exit(1);
	}
}
void CBrFrame::LifeLoop(){
	Mic.ActivateRule(8);
	while (1){
		Input = Sense = Output = "";
		try{
			Input = Sense = Output = "";
			Mic.ActivateRecognizer();
			Input = Mic.Listen();
			Mic.DeActivateRecognizer();
			Input = MiningCenter.toCap(Input);
			OutScreen.Show(Input, 'l');
			SensorForHearings << Input;
			SensorForHearings.Refresh();
			Sense = SensorForHearings.GetSense();
			OutScreen.Show(Sense, 's');
			if (Sense == "GOODBYE"){
				Output = GBRes[rand() % 5];
				OutScreen.Show(Output,'r');
				Speaker.Speak(Output);
				Sleep(500);
				exit(1);
			}
			else if (Sense == "MATHS"){
				string temp = MiningCenter.CleanSTR(Input, Sense);
				OutScreen.Show(temp, 'm');
				Output = to_string(CalculationRegion.MathSolve(temp));
				Output = MathsRes[rand() % 5] + Output;
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				continue;
			}
			else if (Sense == "SIMPLEQUESTION"){
				Output = SelfMemories.Match(Input);
				if (!(Output == "NOANS")){
					OutScreen.Show(Output, 'r');
					Speaker.Speak(Output);
					continue;
				}
				else{
					string temp = MiningCenter.CleanSTR(Input, Sense);
					Output = SelfMemories.Match(temp);
					if (!(Output == "NOANS")){
						OutScreen.Show(Output, 'r');
						Speaker.Speak(Output);
						continue;
					}
					else{
						Output = DicKnowledge.GetMeaning(temp);
						if (!(Output == "NOANS")){
							OutScreen.Show(Output, 'r');
							Speaker.Speak(Output);
							continue;
						}
						else{
							string temp_2 = Input;
							Output = NewKnowledge_Past.GetAnswer(temp_2);
							if (!(Output == "NOANS")){
								OutScreen.Show(Output, 'r');
								Speaker.Speak(Output);
								continue;
							}
							else{
								Output = LearnRes[rand() % 5];
								OutScreen.Show(Output, 'r');
								Speaker.Speak(Output);
								NewKnowledge.Learn(temp_2);
								continue;
							}
						}
					}
				}
			}
			else if (Sense == "SPECIALSIMPLEQUESTION"){
				Output = SPQRes[rand() % 5];
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				continue;
			}
			else if (Sense == "OPENFILE"){
				Output = "STARTING FILE OPENING PROCEDURES";
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				Mic.DeActivateRule(1);
				Output = "Select One of The Drive:\nC\nD\nE\nF\n";
				OutScreen.Show(Output, 'r');
				Speaker.Speak("Select One of The Drive:\n\"C\";\n\"D\";\n\"E\";\n\"F\";\n");
				Mic.AddNewStringToGrammar("Part", 101, "C");
				Mic.AddNewStringToGrammar("Part", 101, "D");
				Mic.AddNewStringToGrammar("Part", 101, "E");
				Mic.AddNewStringToGrammar("Part", 101, "F");
				Mic.AddNewStringToGrammar("Part", 101, "GO BACK");
				string LisDir = "";
				DIR *dir;
				bool PartFlag = 0;
				struct dirent *ent;
				step_1:
				Mic.ActivateRule(101);
				Mic.ActivateRecognizer();
				Input = Mic.Listen();
				Mic.DeActivateRecognizer();
				Mic.DeActivateRule(101);
				LisDir += Input;
				if (PartFlag == 0){
					LisDir += ":";
					PartFlag = 1;
				}
				LisDir += "\\\\";
				Mic.RemoveNewlyAddedStrings();
				Mic.AddNewStringToGrammar("Part", 101, "STOP FILE PROCEDURES");
				if (Input!="STOP FILE PROCEDURES"){
					Output = "OPENING " + Input;
					OutScreen.Show(Output, 'r');
					Speaker.Speak(Output);
					if ((dir = opendir(LisDir.c_str())) != NULL){
						while ((ent = readdir(dir)) != NULL){
							Mic.AddNewStringToGrammar("Part", 101, ent->d_name);
							OutScreen.Show(LisDir+ent->d_name, 'd');
						}
						goto step_1;
					}
					else{
						Output = "EXECUTING FILE WITH WINDOWS DEFAULT PROGRAMME";
						OutScreen.Show(Output, 'r');
						Speaker.Speak(Output);
						LisDir.erase(LisDir.length() - 2, LisDir.length());
						for (int i = 0; i < LisDir.length(); i++){
							while (LisDir[i] == '\\'&&LisDir[i + 1] == '\\'){
								LisDir.erase(i, 1);
							}
						}
						system((char *)LisDir.c_str());
						Mic.DeActivateRule(101);
						Mic.ActivateRule(1);
						continue;
					}

				}
				else{
					Mic.DeActivateRule(101);
					Mic.ActivateRule(1);
					continue;
				}
			}
			else if (Sense == "SOLVEMATHS"){
				Output = "MATHS ACTIVE";
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				Mic.DeActivateRule(1);
				Mic.ActivateRule(2);
				continue;
			}
			else if (Sense == "GOBACK"){
				Output = "RIGHT";
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				Mic.DeActivateRule(2);
				Mic.ActivateRule(1);
				continue;
			}
			else if (Sense == "SAIDOK"){
				string tOK[] = { "OK", "OK WHAT", "HMM" };
				Output = tOK[rand() % 3];
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				Mic.DeActivateRule(8);
				Mic.ActivateRule(1);
				continue;
			}
			else if (Sense == "LISTENSTART"){
				int len = MemPro.LengthOfFile("WelcomeGreatings.txt");
				Output = HelloHi.GetGRT(rand() % len);
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				Mic.DeActivateRule(8);
				Mic.ActivateRule(1);
				continue;
			}
			else if (Sense == "LISTENSTOP"){
				Output = "OK SIR";
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				Mic.DeActivateRule(1);
				Mic.ActivateRule(8);
				continue;
			}
			else if (Sense == "GREETINGS"){
				int len = MemPro.LengthOfFile("WelcomeGreatings.txt");
				Output = HelloHi.GetGRT(rand() % len);
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				continue;
			}
			else if (Sense == "SHUTDOWNPC"){
				string temp[] = { "ARE YOU SURE SIR; SAY YES OR NO", "DO YOU WANT TO SHUTDOWN THE PC; SAY YES OR NO", "SURE TO SHUTDOWN; SAY YES OR NO" };
				Output = "THIS IS CRITICAL; " + temp[rand() % 3];
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				Mic.DeActivateRule(1);
				Mic.ActivateRule(9);
				Mic.ActivateRecognizer();
				Input = Mic.Listen();
				Mic.DeActivateRecognizer();
				Input = MiningCenter.toCap(Input);
				OutScreen.Show(Input, 'l');
				if (Input == "...YES" || Input == "YES..."){
					string resShutdown[] = { "SHUTTING DOWN IN", "SWITCHING THE COMPUTER OFF IN", "TURNING OFF COMPUTER IN" };
					Output = resShutdown[rand() % 3]+" T minus 90 SECONDS. IF YOU WANT TO STOP It SAY \"ABORT SHUTDOWN\"";
					OutScreen.Show(Output, 'r');
					Speaker.Speak(Output);
					system("shutdown /s /t 90 /f");
					Mic.DeActivateRule(9);
					Mic.ActivateRule(1);
					continue;
				}
				else{
					Output = "OK LET'S GO BACK TO NORMAL";
					OutScreen.Show(Output, 'r');
					Speaker.Speak(Output);
					Mic.DeActivateRule(9);
					Mic.ActivateRule(1);
					continue;
				}
			}
			else if (Sense == "ABORTSHUTDOWN"){
				string resAbortShutdown[] = { "ABORTING SHUTDOWN", "STOPING SHUTDOWN QUE", "SHUTDOWN IS BEING ABORTED" };
				Output = resAbortShutdown[rand() % 3];
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				system("shutdown /a");
				continue;
			}
			else if (Sense == "SHOWTERMINAL"){
				Output = "SHOWING TERMINAL";
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				Show(1);
				continue;
			}
			else if (Sense == "HIDETERMINAL"){
				Output = "HIDING TERMINAL";
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				Show(0);
				continue;
			}
			else if (Sense == "NONSENSE"){
				Output = NonSenseRes[rand() % 5];
				OutScreen.Show(Output, 'r');
				Speaker.Speak(Output);
				continue;
			}
		}
		catch (InfoFetcher::FileOpeningError){
			cout << "[Exception] : Some of the Memory Files Failed to Open or Doesn't Exist. Please Verify All Files." << endl;
			exit(1);
		}
		catch (QuestionAnswer::OutOfRange){
			cout << "[Exception] : Array is Full/Empty. No more Objects Can be Pushed/Pulled" << endl;
			exit(1);
		}
		catch (LoadArray<string>::LoadArray_ERROR){
			cout << "[Exception] : Loading Memory Arrays Failed. Try to Reopen; If Failed again Verify Your Copy of Software" << endl;
			exit(1);
		}
		catch (exception e){
			cout << "[Exception] : "<<e.what() << endl;
			exit(1);
		}
	}
}

#endif
