////////////////////////////////////////////////////////////////////////////////////
// Header_File_Name : CBrClass.h
// Description      : This Header File Contains All the Class "PROTOTYPES" and some 
//					  "TEMPLATES" Needed for CBr.
// Coded By         : Muhammad Shahbaz
// Project          : Coded Brain
////////////////////////////////////////////////////////////////////////////////////
#ifndef __CBrClass_H__
#define __CBrClass_H__
////////////////////////////////////////////////////////////////////////////////////
// Required Header Files
////////////////////////////////////////////////////////////////////////////////////
#include "CBrHeader.h"
////////////////////////////////////////////////////////////////////////////////////
// NameSpaces
////////////////////////////////////////////////////////////////////////////////////
using namespace std;
////////////////////////////////////////////////////////////////////////////////////
// Classes Declaration andDefinnitions
////////////////////////////////////////////////////////////////////////////////////

//CBRPrint Class
class CBRPrint{
public:
	void Show(string STR,char type);
	void Line();
	void CLS();
};
//It Initializes the COM Objects
class COMInit{
private:
	HRESULT hr;
public:
	COMInit(){
		hr = S_OK;
	}
	bool Initialize(){
		if (SUCCEEDED(hr = ::CoInitialize(NULL))){
			cout << "[SUCCESS]: COM Initialized." << endl;
			return 1;
		}
		else{
			cout << "[ERROR]: COM Initialized Failed." << endl;
			return 0;
		}
	}
	void Uninitialize(){
		::CoUninitialize();
	}
};
//This is a template class to Load Arrays
template<typename ArrayType>
class LoadArray{
private:
	const int IntSize;
	ArrayType *Ptr;
	fstream file;
public:
	class LoadArray_ERROR{};
	LoadArray(int size) :IntSize(size){
		Ptr = new ArrayType[IntSize];
		file.clear();
	}
	~LoadArray(){
		delete[]Ptr;
	}
	bool Load(string StrDest){
		file.open(StrDest.c_str());
		if (file.is_open()){
			for (int i = 0; i < IntSize; i++){
				getline(file, Ptr[i]);
			}
			return 1;
		}
		else{
			throw LoadArray_ERROR();
			return 0;
		}
	}
	void Clear(){
		Ptr = NULL;
		Ptr = new ArrayType[IntSize];
	}
	ArrayType Get(int Index){
		return Ptr[Index];
	}

};
class SpeakerClass:protected COMInit{
private:
	HRESULT hr;
	CComPtr<ISpVoice>mVoice;
	LPCWSTR CWofStrToSpeak;
public:
	SpeakerClass();
	bool Start();
	void Stop();
	void Speak(string StrToSpeak);
};
class ListenerClass :protected COMInit{
private:
	HRESULT hr;
	CComPtr<ISpRecognizer>mRec;
	CComPtr<ISpAudio>mAudio;
	CComPtr<ISpRecoContext>mCon;
	CComPtr<ISpRecoGrammar>mGrm;
	CSpEvent mEvent;
	ISpPhrase *mIPhrase;
	LPWSTR mOut;
	string mOutText;
	SPSTATEHANDLE SPAddState;
public:
	ListenerClass();
	bool Start();
	bool ActivateRecognizer();
	bool DeActivateRecognizer();
	bool LoadDictation();
	bool UnLoadDictation();
	bool ActivateDictation();
	bool DeActivateDictation();
	bool LoadCmdFromSource();
	bool ActivateAllRule();
	bool DeActivateAllRule();
	bool ActivateRule(ULONG RuleID);
	bool DeActivateRule(ULONG RuleID);
	bool AddNewStringToGrammar(string RuleName, int RuleID,string StringToAdd);
	bool RemoveNewlyAddedStrings();
	void Stop();
	string Listen();
};
class InfoFetcher{
private:
	size_t pos;
public:
	class FileOpeningError{};
	InfoFetcher();
	int LengthOfFile(string FileName);
};
//Class Whoes Objects will have Unnecessory Words So that We can Get Main Point
class RemovableStrings :protected LoadArray < string > {
private:
	string *Str;
	int CountRemovableStrings;
	const int SizeStr;
public:
	RemovableStrings(int TotalRemovableStrings);
	~RemovableStrings();
	string GetStr(int Index)const;
	int GetSize()const;
};
//Class Which Parse The String For CBr
class Parser{
private:
	RemovableStrings RSTRObj;
	size_t pos;
public:
	Parser(int TotalRemovableStrings);
	string toCap(string Target);
	void StringReplace(string &Strstr, string StrTarget, string StrSource);
	void StringAllSpaceRemove(string &Strstr);
	void StringExtraSpaceRemove(string &Strstr);
	size_t FindStr(string Source, string Str);
	void StringReplaceWord(string &Strstr, string StrTarget, string StrSource);
	string CleanSTR(string Target, string ForWhat);
	int CountWords(string Target);
	string Transpose(string Target);
};
class MathSolver{
private:
	Parser PRSObj;
	const string StrMathSign;
	string Chunk, StrPreNum, StrPostNum;
	long double LngDblPreNum, LngDblPostNum;
	int IntPosPre,IntPosPost;
	char ChrMathSign;
protected:
	//It Retruns First Mathematical Sign Position From(0) or Upto(1) Specific Index in a String
	int IntFindFirstMathSign(string Strstr, int IntPos, int Flag);
	int IntFindFirstMathSign(string Strstr, char ChrMathSign);
	int IntFindLastMathSign(string Strstr, char ChrMathSign);
	int IntFindLastMathSign(string Strstr, int IntPos, int Flag);
	string StrChunkExtract(string Strstr, char ChrMathSign);
	long double LngDblChunkSolve(string StrMathChunk);
public:
	MathSolver(int TotalRemovableStrings);
	long double MathSolve(string Strstr);
};
//Class QuestionAnswer Objects
class QuestionAnswer{
private:
	Parser PRSObj;
	string *Q, *A;
	const int SizeQ, SizeA;
	int CQ, CA;
public:
	class OutOfRange{};
	QuestionAnswer();
	QuestionAnswer(int nOfQues, int nOfAns, int TotalRemovableStrings);
	~QuestionAnswer();
	void PushQ(string STR);
	void PushA(string STR);
	string GetAns(string Question);
};
//Dictionary Class Child of LoadArray Class Strength=89517
class Dictionary :protected LoadArray<string>{
	string *word, *meaning;
	int CountWord, CountMeaning;
	const int TotalLines;
public:
	Dictionary(int TotalDicLines);
	string GetMeaning(string Word);
};
//Class Which gives us Objects which have Question Strings
class QuestionStrings :protected LoadArray < string > {
private:
	string *QStr, *SQStr;
	int CountQStr, CountSQStr;
	const int SizeQStr, SizeSQStr, TotalLines;
public:
	QuestionStrings(int TotalQuestionStrings);
	~QuestionStrings();
	string GetQStr(int Index)const;
	string GetSQStr(int Index)const;
	int GetTotalLines()const;
	int GetSizeQStr()const;
	int GetSizeSQStr()const;
};
//Class to Load Greetings
class Greetings :protected LoadArray < string > {
private:
	string *GRT;
	int CountGRT;
	const int SizeGRT;
public:
	Greetings(int TotalGreetings);
	~Greetings();
	string GetGRT(int Index)const;
	int GetSizeGRT()const;
};
class SimpleMatch:protected LoadArray<string>{
private:
	string *Str;
	QuestionAnswer *QA;
	int Hashes,QAIndex;
public:
	SimpleMatch(int TotalSimpleMatch);
	string Match(string QuestionSTR);
};
//Templatet for CBR Inputs And Outputs
template<typename CBRIO_ARG>
class CBRIO{
protected:
	CBRIO_ARG *ARG;
public:
	CBRIO(){
		ARG = new CBRIO_ARG;
	}
	~CBRIO(){
		delete ARG;
	}
	void operator <<(CBRIO_ARG Source){
		*ARG = Source;
	}
	void operator >>(CBRIO_ARG &Sink){
		Sink = *ARG;
	}
	//Get ARG
	CBRIO_ARG PullARG(){
		return *ARG;
	}
	//Put ARG
	void PushARG(CBRIO_ARG Source){
		ARG = Source;
	}
};
class Understander :public CBRIO < string >{
protected:
	string Input;
	QuestionStrings QSTRObj;
	Parser PRSObj;
private:
	//bool isHideTerminal
	bool isHideTerminal();
	//bool isShowTerminal
	bool isShowTerminal();
	//bool isAbortShutdown
	bool isAbortShutdown();
	//bool isShutdownPC
	bool isShutdownPC();
	//bool isOK
	bool isOK();
	//bool goback
	bool isGoBack();
	//bool isSolveMaths
	bool isSolveMaths();
	//bool LISTEN START exist
	bool isLisStart();
	//bool LISTEN STOP exist
	bool isLisStop();
	//bool Greatings exist
	bool isGreetings();
	//bool Open File Exist
	bool ISOpenFile();
	//Does Simple Question exist
	bool SimpleQuestion();
	//Does Special Simple Question exist
	bool SpecialSimpleQuestion();
	//Does Maths Exist
	bool MathExist();
	//Does Good Bye Exist
	bool GoodByeExist();
public:
	Understander(int TotalQuestionStrings, int TotalRemovableStrings);
	void Refresh();
	string GetSense();
	string GetInput();
};
class FileWriter{
private:
	fstream file;
public:
	FileWriter();
	~FileWriter();
	void Open(string, ios_base::open_mode);
	void Write(string Line);
	void Close();
};
class Learner{
private:
	CBRPrint LearnPrint;
	ListenerClass LearnListener;
	FileWriter *Memorize;
	Parser *ParseforLearn;
public:
	Learner(int);
	~Learner();
	void Start();
	void Learn(string);
	void Stop();
};
class LearnedMatch :protected LoadArray < string > {
private:
	int QAIndex;
	string *Q, *A;
	int TotalLinesC;
	Parser *ParseforLearnedMatch;
public:
	LearnedMatch(int, int);
	~LearnedMatch();
	string GetAnswer(string);
};
//IT is MAIN CLASS whoes OBJETS WILL ACT LIKE CODED BRAINS
class CBrFrame{
private:
	ListenerClass Mic;
	SpeakerClass Speaker;
	Understander SensorForHearings;
	Parser MiningCenter;
	SimpleMatch SelfMemories;
	Dictionary DicKnowledge;
	MathSolver CalculationRegion;
	Greetings HelloHi;
	Learner NewKnowledge;
	LearnedMatch NewKnowledge_Past;
	CBRPrint OutScreen;
	InfoFetcher MemPro;
	string Input, Sense, Output;
	string MathsRes[5], SPQRes[5], NonSenseRes[5],LearnRes[5],GBRes[5];
public:
	CBrFrame();
	void Energize();
	void LifeLoop();
};
//Show Hide Function
void Show(int Val = 1){
	HWND CBRTerminal;
	AllocConsole();
	CBRTerminal = FindWindowA("ConsoleWindowClass", NULL);
	ShowWindow(CBRTerminal, Val);
}
#endif
